+----------------------------------------------------------------------+
|                 SLOVENSKA TECHNICKA UNIVERZITA                       |
|             FAKULTA INFORMATIKY A ELEKTROTECHNIKY                    |
|                                                                      |
|     Diplomova praca: Podpisove schemy v postkantovej kryptografii    |
|                      Autor: Pavol Dobrocka                           |
|                            Rok: 2016                                 |
+----------------------------------------------------------------------+ 

                               PRILOHA:
                             
                               BitPunch
Priecinok bitpunch obsahuje zdrojove kody kniznice BitPunch
rozsirene o LDGM podpisove schemy. 
Subor main.c obsahuje kod pomocou ktoreho bolo vykonane testovanie
invertovania QC matic a vykonnost LDGM implementacie
Kod v subore main.c je prispobeny na operacny system Windows

                              Meranie
Priecinok measurements obsahuje vsetky vysledky testovania, ktore
boli nad implementaciou vykonane

                               Demo
Demo aplikacia, ktora umoznuje pomocou LDGM vygenerovat klucovy par,
podpisat subor a overit podpis sa nachadza v priecinku demo spolu s
manualom na obsluhu